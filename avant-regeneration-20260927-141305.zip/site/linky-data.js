window.LINKY_DATA = {
  "status": "attention",
  "last_sync": "2026-09-27T11:43:03Z",
  "last_data": "2026-09-27",
  "last_daily_data": "2026-09-25",
  "summary": {
    "start": "2023-09-05",
    "end": "2026-09-25",
    "consumption_kwh": 10011.3,
    "injection_kwh": 5580.2,
    "consumption_start": "2023-09-05",
    "consumption_end": "2026-09-25",
    "injection_start": "2024-11-19",
    "injection_end": "2026-09-25",
    "max_power_va": 4398.0,
    "note": "Injection réseau mesurée par Linky; ce n'est pas la production photovoltaïque totale."
  },
  "load_curves": {
    "consumption": {
      "complete_days": 20,
      "incomplete_days": [],
      "last_measurement": "2026-09-25T22:00:00Z",
      "last_complete_day": "2026-09-25"
    },
    "production": {
      "complete_days": 36,
      "incomplete_days": [],
      "last_measurement": "2026-09-26T22:00:00Z",
      "last_complete_day": "2026-09-26"
    }
  }
};
